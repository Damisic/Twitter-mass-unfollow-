chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "START_UNFOLLOW") {
    console.log("Starting batch: " + request.limit);
    unfollowBatch(request.limit);
  }
});

// Helper function to wait (delay)
const wait = (ms) => new Promise(r => setTimeout(r, ms));

async function unfollowBatch(limit) {
  let count = 0;
  let retryCount = 0;

  while (count < limit) {
    // 1. Find all "Following" buttons on the screen
    // We look for the button that says "Following"
    let buttons = Array.from(document.querySelectorAll('[role="button"]'))
      .filter(btn => btn.innerText === "Following" || btn.getAttribute('data-testid')?.includes('unfollow'));

    if (buttons.length === 0) {
      // If no buttons found, scroll down to load more
      console.log("No more buttons found, scrolling...");
      window.scrollBy(0, 800);
      await wait(2000); // Wait for X to load new users
      retryCount++;
      
      if (retryCount > 5) {
        alert("Reached the end of the list or X is blocking the script.");
        break;
      }
      continue;
    }

    for (const btn of buttons) {
      if (count >= limit) break;

      try {
        // Find the parent cell to check if they follow you
        const userCell = btn.closest('[data-testid="UserCell"]');
        const followsYou = userCell ? userCell.innerText.includes("Follows you") : false;

        // LOGIC: Only unfollow if they DON'T follow you
        if (!followsYou) {
          btn.scrollIntoView({ block: 'center' });
          btn.click(); // Click the "Following" button
          
          await wait(1000); // Wait for the confirmation popup

          // 2. Find the "Unfollow" confirmation button in the popup
          const confirmBtn = document.querySelector('[data-testid="confirmationSheetConfirm"]');
          
          if (confirmBtn) {
            confirmBtn.click();
            count++;
            console.log(`✅ Unfollowed: ${count}/${limit}`);
            
            // 3. Human-like delay (IMPORTANT: To prevent account ban)
            const delay = Math.floor(Math.random() * 3000) + 4000; // 4-7 seconds
            await wait(delay);
          }
        } else {
          console.log("Skipping follower...");
        }
      } catch (err) {
        console.error("Error clicking button:", err);
      }
    }
    
    // Scroll down after processing the current batch of visible buttons
    window.scrollBy(0, 1000);
    await wait(2000);
  }

  alert(`Done! Successfully unfollowed ${count} accounts.`);
}
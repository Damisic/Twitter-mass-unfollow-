document.querySelectorAll('button').forEach(btn => {
  btn.addEventListener('click', async () => {
    const limit = parseInt(btn.id.replace('batch', ''));
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (tab.url.includes('/following')) {
      chrome.tabs.sendMessage(tab.id, { action: "START_UNFOLLOW", limit: limit });
      document.getElementById('status').innerText = `Running batch of ${limit}...`;
    } else {
      alert("Please go to your 'Following' page first.");
    }
  });
});
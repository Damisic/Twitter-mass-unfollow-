chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "START_UNFOLLOW") {
    unfollowLogic(request.limit);
  }
});

async function unfollowLogic(limit) {
  let count = 0;
  console.log(`%c [0xDamisi Tool] Initiating batch: ${limit}`, "color: #1da1f2; font-weight: bold;");

  while (count < limit) {
    // 1. Get all user rows visible on screen
    const userCells = Array.from(document.querySelectorAll('[data-testid="UserCell"]'));
    
    if (userCells.length === 0) {
      window.scrollBy(0, 1000);
      await new Promise(r => setTimeout(r, 2000));
      continue;
    }

    for (const cell of userCells) {
      if (count >= limit) break;

      // 2. DETECT: Skip if they follow you back
      const followsYou = cell.innerText.includes("Follows you");

      if (!followsYou) {
        // Find the "Following" button
        const btn = cell.querySelector('[data-testid$="-unfollow"]') || 
                    Array.from(cell.querySelectorAll('[role="button"]')).find(b => b.innerText === "Following");

        if (btn) {
          btn.scrollIntoView({ block: 'center' });
          btn.click();
          
          await new Promise(r => setTimeout(r, 600)); // Wait for modal
          
          const confirm = document.querySelector('[data-testid="confirmationSheetConfirm"]');
          if (confirm) {
            confirm.click();
            count++;
            console.log(`[${count}/${limit}] Unfollowed account.`);
            
            // Randomized human-like delay (5 to 9 seconds)
            const delay = Math.floor(Math.random() * 4000) + 5000;
            await new Promise(r => setTimeout(r, delay));
          }
        }
      }
    }

    // 3. Scroll to load more content
    window.scrollBy(0, window.innerHeight);
    await new Promise(r => setTimeout(r, 2500));

    // Stop if we hit the bottom of the page
    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {
      console.log("[0xDamisi Tool] Reached the end of list.");
      break;
    }
  }

  alert(`Done! Successfully unfollowed ${count} accounts who don't follow you back.`);
}
document.getElementById('startBtn').addEventListener('click', async () => {
  const amount = parseInt(document.getElementById('customAmount').value);
  const status = document.getElementById('status');
  
  if (isNaN(amount) || amount <= 0) {
    alert("Please enter a valid number.");
    return;
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  if (tab.url.includes('/following')) {
    chrome.tabs.sendMessage(tab.id, { action: "START_UNFOLLOW", limit: amount });
    status.innerText = `Unfollowing ${amount} users...`;
    status.style.color = "#f45d22"; // Orange for "In Progress"
  } else {
    alert("Please navigate to your 'Following' page first.");
  }
});

// Logic to make the watermark link work
document.getElementById('authorLink').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: "https://x.com/0xDamisi" });
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "CROSS_CHECK_UNFOLLOW") {
    crossCheck(request.limit);
  }
});

async function crossCheck(limit) {
  let unfollowedCount = 0;
  console.log(`%c [0xDamisi Cross-Checker] Target: ${limit} non-followers`, "color: #1da1f2; font-weight: bold;");

  while (unfollowedCount < limit) {
    // 1. Grab all user cards currently visible
    const users = Array.from(document.querySelectorAll('[data-testid="UserCell"]'));
    
    if (users.length === 0) {
      console.log("No users found, scrolling...");
      window.scrollBy(0, 1000);
      await new Promise(r => setTimeout(r, 2000));
      continue;
    }

    for (const user of users) {
      if (unfollowedCount >= limit) break;

      // 2. THE CROSS CHECK LOGIC
      // If the cell contains "Follows you", they are a mutual follower.
      const isMutual = user.innerText.includes("Follows you");

      if (!isMutual) {
        // Find the "Following" button for this specific non-follower
        const unfollowBtn = user.querySelector('[data-testid$="-unfollow"]') || 
                           Array.from(user.querySelectorAll('[role="button"]')).find(b => b.innerText === "Following");

        if (unfollowBtn) {
          unfollowBtn.scrollIntoView({ block: 'center', behavior: 'smooth' });
          unfollowBtn.click();
          
          // Wait for confirmation popup
          await new Promise(r => setTimeout(r, 1000));
          
          const confirm = document.querySelector('[data-testid="confirmationSheetConfirm"]');
          if (confirm) {
            confirm.click();
            unfollowedCount++;
            console.log(`%c ✅ Removed Non-Follower (${unfollowedCount}/${limit})`, "color: #ff4b2b;");
            
            // Random human-like delay to avoid being flagged as a bot (7-12 seconds)
            const delay = Math.floor(Math.random() * 5000) + 7000;
            await new Promise(r => setTimeout(r, delay));
          }
        }
      } else {
        // Optional: Log who we are skipping
        // console.log("Skipping mutual follower...");
      }
    }

    // Scroll down to load the next set of users
    window.scrollBy(0, window.innerHeight);
    await new Promise(r => setTimeout(r, 3000));

    // Check if we hit the bottom of the page
    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {
      console.log("Reached the end of your following list.");
      break;
    }
  }

  alert(`Cross-check complete! ${unfollowedCount} non-followers removed.`);
}